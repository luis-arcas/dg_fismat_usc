% Programa principal destinado a resolver numericamente 
% un PVI del tipo 
%
%    dy(x)/dx = f(x,y(x)),    x in [a,b]
%        y(a) = eta,
%
% mediante un integrador temporal de tipo Runge-Kutta.

% Definicion del PVI.
a   = ...;        % Tiempo inicial.
b   = ...;        % Tiempo final.
eta = ...;        % y(a).
f   = @(x,y) ...; % Funcion que define la EDO.
sol = @(x) ...;   % Solucion del PVI.

% Parametros para el integrador.
h   = ...;        % Parametro de discretizacion.
N   = ...;        % Numero total de pasos.
fid = fopen('SalidaEj1.txt','w'); % fid para salidas.

% Llamada al Runge-Kutta. 
% [arg_salida] = ERK3(arg_entrada);

% Cierre del fichero de salida.
fclose(fid);





